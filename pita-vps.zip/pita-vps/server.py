#!/usr/bin/env python3
"""
PITA VPS — يحوّل أي بث (MPD / HLS / TS / RTMP ...) إلى HLS متوافق مع المتصفح عبر ffmpeg.

مكتبات Python القياسية فقط (لا pip). يحتاج ffmpeg + ffprobe.

نقاط النهاية:
  GET /health                          حالة الخدمة
  GET /live/<id>.m3u8                  قناة معرَّفة مسبقًا في channels.json  (الرابط الحقيقي يبقى سرًّا على الخادم)
  GET /live/x.m3u8?u=<url>&key=<KEY>   رابط حرّ — يحتاج PITA_KEY (للتجارب وللإدارة فقط)
       خيارات اختيارية: ref=<Referer>  ua=<User-Agent>  aac=1 (تحويل الصوت إلى AAC)  vh=<أقصى ارتفاع للفيديو>
  GET /hls/<sid>/<file>                مقاطع الجلسة (داخلي، يُكتب تلقائيًا داخل القائمة)

متغيرات البيئة (كلها اختيارية ما عدا PITA_KEY إن أردت الروابط الحرّة):
  PITA_PORT=8080            PITA_HOST=0.0.0.0
  PITA_KEY=...              مفتاح الروابط الحرّة (بدونه تُرفض الروابط الحرّة)
  PITA_ORIGINS=https://pitadz14.github.io   مواقع مسموحة (فاصلة بينها)، أو *
  PITA_CHANNELS=/etc/pita-vps/channels.json
  PITA_DIR=/var/lib/pita-vps                مكان ملفات HLS المؤقتة (يُفضَّل tmpfs)
  PITA_MAX_SESSIONS=3       أقصى عدد قنوات تُحوَّل معًا (حسب المعالج/الذاكرة)
  PITA_IDLE_SEC=45          يُوقف التحويل إذا لم يطلبه أحد خلال هذه المدة
  PITA_ALLOW_PRIVATE=0      1 = اسمح بعناوين محلية/خاصة (للاختبار فقط)
  PITA_FFMPEG=ffmpeg  PITA_FFPROBE=ffprobe
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PITA_PORT", "8080"))
HOST = os.environ.get("PITA_HOST", "0.0.0.0")
KEY = os.environ.get("PITA_KEY", "")
ORIGINS = [o.strip() for o in os.environ.get("PITA_ORIGINS", "https://pitadz14.github.io").split(",") if o.strip()]
CHANNELS_FILE = Path(os.environ.get("PITA_CHANNELS", str(Path(__file__).with_name("channels.json"))))
BASE_DIR = Path(os.environ.get("PITA_DIR", "/tmp/pita-vps"))
MAX_SESSIONS = int(os.environ.get("PITA_MAX_SESSIONS", "3"))
IDLE_SEC = int(os.environ.get("PITA_IDLE_SEC", "45"))
ALLOW_PRIVATE = os.environ.get("PITA_ALLOW_PRIVATE", "0") == "1"
FFMPEG = os.environ.get("PITA_FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("PITA_FFPROBE", "ffprobe")
START_TIMEOUT = 30           # أقصى انتظار لظهور أول قائمة
SALT = os.urandom(16)        # يجعل معرّف الجلسة غير قابل للتخمين

DEFAULT_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
SAFE_FILE = re.compile(r"^[A-Za-z0-9_.-]{1,80}$")
SID_RE = re.compile(r"^[0-9a-f]{16}$")


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


# ───────────────────────── أدوات ─────────────────────────
def host_is_private(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False  # سيفشل ffmpeg بنفسه
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return True
    return False


def check_source_url(url: str) -> str | None:
    p = urlparse(url)
    if p.scheme not in ("http", "https", "rtmp", "rtmps", "rtsp"):
        return "نوع الرابط غير مدعوم"
    if not p.hostname:
        return "رابط بلا مضيف"
    if not ALLOW_PRIVATE and host_is_private(p.hostname):
        return "العناوين المحلية/الخاصة محظورة"
    return None


def load_channels() -> dict:
    try:
        data = json.loads(CHANNELS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {k: v for k, v in data.items() if isinstance(v, dict) and isinstance(v.get("url"), str)
            and not k.startswith("_")}


# ───────────────────────── جلسات ffmpeg ─────────────────────────
class Session:
    def __init__(self, sid: str, opts: dict):
        self.sid = sid
        self.opts = opts
        self.dir = BASE_DIR / sid
        self.proc: subprocess.Popen | None = None
        self.last = time.time()
        self.started = time.time()
        self.lock = threading.Lock()
        self.err_tail: list[str] = []

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def touch(self):
        self.last = time.time()

    def playlist(self) -> Path:
        return self.dir / "index.m3u8"

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        shutil.rmtree(self.dir, ignore_errors=True)


SESSIONS: dict[str, Session] = {}
SESSIONS_LOCK = threading.Lock()


def pick_streams(url: str, headers: str, ua: str, max_h: int) -> list[str]:
    """يختار أفضل مسار فيديو (أعلى دقة ضمن الحد) وأول مسار صوت، عبر ffprobe. عند الفشل: الافتراضي."""
    cmd = [FFPROBE, "-v", "error", "-user_agent", ua]
    if headers:
        cmd += ["-headers", headers]
    cmd += ["-print_format", "json", "-show_streams", url]
    try:
        out = subprocess.run(cmd, capture_output=True, timeout=25, text=True).stdout
        streams = json.loads(out).get("streams", [])
    except Exception:
        return ["-map", "0:v:0?", "-map", "0:a:0?"]
    videos = [s for s in streams if s.get("codec_type") == "video" and s.get("codec_name") != "mjpeg"]
    audios = [s for s in streams if s.get("codec_type") == "audio"]
    maps: list[str] = []
    if videos:
        def key(s):
            h = int(s.get("height") or 0)
            ok = 1 if (not max_h or h <= max_h) else 0
            return (ok, h if ok else -h, int(s.get("bit_rate") or 0))
        best = max(videos, key=key)
        maps += ["-map", f"0:{best['index']}"]
    if audios:
        maps += ["-map", f"0:{audios[0]['index']}"]
    return maps or ["-map", "0:v:0?", "-map", "0:a:0?"]


def start_ffmpeg(s: Session):
    o = s.opts
    s.dir.mkdir(parents=True, exist_ok=True)
    for f in s.dir.iterdir():
        f.unlink(missing_ok=True)
    ua = o.get("ua") or DEFAULT_UA
    headers = ""
    if o.get("ref"):
        pr = urlparse(o["ref"])
        headers = f"Referer: {o['ref']}\r\nOrigin: {pr.scheme}://{pr.netloc}\r\n"
    maps = pick_streams(o["url"], headers, ua, int(o.get("vh") or 0))
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "warning", "-nostdin",
           "-protocol_whitelist", "http,https,tcp,tls,crypto,data,rtmp,rtsp,udp,rtp",
           "-user_agent", ua]
    if headers:
        cmd += ["-headers", headers]
    cmd += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
            "-fflags", "+genpts", "-i", o["url"]] + maps
    cmd += ["-c:v", "copy"]
    cmd += (["-c:a", "aac", "-b:a", "128k", "-ac", "2"] if o.get("aac") else ["-c:a", "copy"])
    cmd += ["-f", "hls", "-hls_time", "4", "-hls_list_size", "8",
            "-hls_flags", "delete_segments+independent_segments+omit_endlist",
            "-hls_segment_filename", str(s.dir / "seg_%05d.ts"), str(s.playlist())]
    log(f"[{s.sid}] ffmpeg ← {urlparse(o['url']).netloc}{urlparse(o['url']).path[:40]}")
    s.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, bufsize=1)

    def drain():
        for line in s.proc.stderr:  # type: ignore[union-attr]
            s.err_tail.append(line.strip())
            del s.err_tail[:-8]
    threading.Thread(target=drain, daemon=True).start()


def wait_ready(s: Session) -> str | None:
    """ينتظر ظهور قائمة فيها مقطعان على الأقل. يرجع نص الخطأ أو None."""
    t0 = time.time()
    while time.time() - t0 < START_TIMEOUT:
        if not s.alive():
            return "توقف ffmpeg: " + " | ".join(s.err_tail[-3:])[:300]
        p = s.playlist()
        if p.exists():
            try:
                if p.read_text().count("#EXTINF") >= 2:
                    return None
            except OSError:
                pass
        time.sleep(0.4)
    return "انتهت مهلة بدء البث"


def get_session(opts: dict) -> tuple[Session | None, str | None]:
    sid = hmac.new(SALT, json.dumps(opts, sort_keys=True).encode(), hashlib.sha1).hexdigest()[:16]
    with SESSIONS_LOCK:
        s = SESSIONS.get(sid)
        if s is None:
            running = [x for x in SESSIONS.values() if x.alive()]
            if len(running) >= MAX_SESSIONS:
                return None, f"الحد الأقصى للقنوات المتزامنة ({MAX_SESSIONS}) — حاول لاحقًا"
            s = Session(sid, opts)
            SESSIONS[sid] = s
    with s.lock:
        s.touch()
        if not s.alive():
            s.err_tail.clear()
            start_ffmpeg(s)
            err = wait_ready(s)
            if err:
                s.stop()
                with SESSIONS_LOCK:
                    SESSIONS.pop(sid, None)
                return None, err
        s.touch()
    return s, None


def reaper():
    while True:
        time.sleep(5)
        now = time.time()
        with SESSIONS_LOCK:
            for sid, s in list(SESSIONS.items()):
                if now - s.last > IDLE_SEC or (not s.alive() and now - s.started > START_TIMEOUT):
                    log(f"[{sid}] إيقاف (خمول/توقف)")
                    s.stop()
                    SESSIONS.pop(sid, None)


# ───────────────────────── HTTP ─────────────────────────
class Handler(BaseHTTPRequestHandler):
    server_version = "pita-vps"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # أقل ضجيجًا
        if "/hls/" not in (args[0] if args else ""):
            log(self.address_string(), fmt % args)

    # CORS
    def cors(self) -> dict:
        origin = self.headers.get("Origin", "")
        allow = "*" if "*" in ORIGINS else (origin if origin in ORIGINS else (ORIGINS[0] if ORIGINS else ""))
        return {"Access-Control-Allow-Origin": allow, "Vary": "Origin",
                "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
                "Access-Control-Allow-Headers": "Range, Content-Type",
                "Access-Control-Expose-Headers": "Content-Length, Content-Range",
                "Cache-Control": "no-store"}

    def reply(self, code: int, body: bytes = b"", ctype: str = "text/plain; charset=utf-8", extra: dict | None = None):
        self.send_response(code)
        for k, v in {**self.cors(), **(extra or {})}.items():
            self.send_header(k, v)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_OPTIONS(self):
        self.reply(204)

    do_HEAD = lambda self: self.do_GET()

    def origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        return not origin or "*" in ORIGINS or origin in ORIGINS

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        parts = [p for p in u.path.split("/") if p]
        try:
            if u.path == "/health":
                with SESSIONS_LOCK:
                    n = sum(1 for s in SESSIONS.values() if s.alive())
                return self.reply(200, json.dumps({"ok": True, "sessions": n, "max": MAX_SESSIONS}).encode(),
                                  "application/json")
            if len(parts) == 2 and parts[0] == "live" and parts[1].endswith(".m3u8"):
                return self.live(parts[1][:-5], q)
            if len(parts) == 3 and parts[0] == "hls":
                return self.segment(parts[1], parts[2])
            return self.reply(200, b"PITA VPS OK")
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:  # لا نكشف تفاصيل داخلية
            log("خطأ:", repr(exc))
            try:
                self.reply(500, b"internal error")
            except Exception:
                pass

    def live(self, name: str, q: dict):
        if not self.origin_ok():
            return self.reply(403, b"origin not allowed")
        ch = load_channels().get(name)
        if ch is not None:
            opts = {"url": ch["url"], "ref": ch.get("referer", ""), "ua": ch.get("ua", ""),
                    "aac": bool(ch.get("aac")), "vh": int(ch.get("max_height") or 0)}
        else:
            # رابط حرّ: مفتاح إلزامي
            if not KEY or not hmac.compare_digest(q.get("key", ""), KEY):
                return self.reply(404 if not q.get("u") else 403, b"unknown channel or bad key")
            if not q.get("u"):
                return self.reply(400, b"missing u")
            opts = {"url": q["u"], "ref": q.get("ref", ""), "ua": q.get("ua", ""),
                    "aac": q.get("aac") == "1", "vh": int(q.get("vh") or 0)}
        bad = check_source_url(opts["url"])
        if bad:
            return self.reply(400, bad.encode())
        s, err = get_session(opts)
        if err or s is None:
            return self.reply(502, (err or "failed").encode())
        text = s.playlist().read_text()
        out = []
        for line in text.splitlines():
            if line and not line.startswith("#"):
                line = f"/hls/{s.sid}/{line}"     # مسار مطلق → يعمل مهما كان الأساس
            out.append(line)
        self.reply(200, ("\n".join(out) + "\n").encode(), "application/vnd.apple.mpegurl")

    def segment(self, sid: str, fname: str):
        if not SID_RE.match(sid) or not SAFE_FILE.match(fname):
            return self.reply(400, b"bad path")
        with SESSIONS_LOCK:
            s = SESSIONS.get(sid)
        if s is None:
            return self.reply(404, b"no session")
        s.touch()
        f = s.dir / fname
        if not f.is_file():
            return self.reply(404, b"not found")
        ctype = "video/mp2t" if fname.endswith(".ts") else "application/vnd.apple.mpegurl"
        self.reply(200, f.read_bytes(), ctype)


def main():
    if not shutil.which(FFMPEG):
        sys.exit("ffmpeg غير مثبّت (sudo apt install ffmpeg)")
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=reaper, daemon=True).start()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    srv.daemon_threads = True

    def shutdown(*_):
        log("إيقاف…")
        with SESSIONS_LOCK:
            for s in SESSIONS.values():
                s.stop()
        os._exit(0)
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    log(f"PITA VPS على {HOST}:{PORT} — قنوات معرّفة: {len(load_channels())} — "
        f"روابط حرّة: {'مفعّلة' if KEY else 'معطّلة (لا PITA_KEY)'}")
    srv.serve_forever()


if __name__ == "__main__":
    main()
