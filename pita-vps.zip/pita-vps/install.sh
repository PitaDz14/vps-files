#!/usr/bin/env bash
# تثبيت PITA VPS على Ubuntu/Debian. شغّله من داخل مجلد pita-vps بصلاحية root:   sudo bash install.sh
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "شغّله بـ root: sudo bash install.sh"; exit 1; }
cd "$(dirname "$0")"

echo "▶ تثبيت الحزم…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq ffmpeg python3 curl ca-certificates

echo "▶ إنشاء المستخدم والمجلدات…"
id pita >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin pita
mkdir -p /opt/pita-vps /etc/pita-vps
install -m 0644 server.py /opt/pita-vps/server.py
[ -f /etc/pita-vps/channels.json ] || install -m 0640 -o root -g pita channels.example.json /etc/pita-vps/channels.json

if [ ! -f /etc/pita-vps/env ]; then
  KEY=$(python3 -c 'import secrets;print(secrets.token_urlsafe(24))')
  cat > /etc/pita-vps/env <<ENV
PITA_PORT=8080
PITA_HOST=0.0.0.0
PITA_KEY=$KEY
PITA_ORIGINS=https://pitadz14.github.io
PITA_CHANNELS=/etc/pita-vps/channels.json
PITA_DIR=/run/pita-vps
PITA_MAX_SESSIONS=3
PITA_IDLE_SEC=45
ENV
  chmod 0640 /etc/pita-vps/env; chgrp pita /etc/pita-vps/env
  echo "▶ أُنشئ مفتاح الروابط الحرّة: $KEY   (محفوظ في /etc/pita-vps/env)"
fi

install -m 0644 systemd/pita-vps.service /etc/systemd/system/pita-vps.service
systemctl daemon-reload
systemctl enable --now pita-vps
sleep 2
systemctl --no-pager --lines=5 status pita-vps || true
echo
echo "▶ اختبار محلي:"; curl -s localhost:8080/health; echo
echo "تم. عدّل القنوات في /etc/pita-vps/channels.json (لا حاجة لإعادة التشغيل)."
